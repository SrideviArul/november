package com.file.demo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Entity
@Table(name = "file")
public class FileEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", columnDefinition = "INT UNSIGNED")
	private int id;
	@Column(name = "name", columnDefinition = "VARCHAR(30)")
	private String name;
	@Column(name = "file_name", columnDefinition = "VARCHAR(20)")
	private String fileName;
//	@Column(name = "display_name")
//	private String displayName;
	@Column(name = "path", columnDefinition = "VARCHAR(70)")
	private String path;
	@Column(name = "link", columnDefinition = "VARCHAR(100)")
	private String link;

//	@Transient
//	private HttpHeaders httpHeaders;
//
//	@Transient
//	private String reupload;
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}
//
//	public HttpHeaders getHttpHeaders() {
//		return httpHeaders;
//	}
//
//	public void setHttpHeaders(HttpHeaders httpHeaders) {
//		this.httpHeaders = httpHeaders;
//	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}
//
//	public String getReupload() {
//		return reupload;
//	}
//
//	public void setReupload(String reupload) {
//		this.reupload = reupload;
//	}
}
