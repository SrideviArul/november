package com.file.demo.service;

import java.io.File;
import org.apache.commons.io.FilenameUtils;
import org.apache.tika.Tika;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import com.file.demo.dto.FileDto;
import com.file.demo.entity.FileEntity;
import com.file.demo.exception.HandlingException;
import com.file.demo.repository.FileRepository;

@Service
public class FileServiceImplementation implements FileService {
	
    private static final Logger LOGGER = LoggerFactory.getLogger(FileServiceImplementation.class);
    
	@Autowired
	public FileRepository fileRepository;
	@Value("${spring.servlet.multipart.location}")
	private String uploadDir;
	@Value("${spring.file.allowed-types}")
	private String[] fileTypes;

	@Override
	public FileDto create(FileEntity objects, List<MultipartFile> values) throws IOException {
		// list of values should be return
		List<FileEntity> listFile = new ArrayList<>();
		FileDto savedFile = new FileDto();
		List<String> errorMessage = new ArrayList<String>();
		for (MultipartFile fil : values) {
			try {
				
				if (fil.isEmpty()) {
					errorMessage.add("file is empty" + " " + fil.getOriginalFilename());
				}
				LOGGER.info("File upload started : " + fil.getName());
				if (!(FilenameUtils.isExtension(fil.getOriginalFilename(), fileTypes))) {
					errorMessage.add("Invalid File" + " " + fil.getOriginalFilename());
				}
				Tika tika = new Tika();
				String determineType = tika.detect(fil.getInputStream());
				System.out.println(fil.getContentType());
				System.out.println(fil.getInputStream());
				if (!determineType.equals(fil.getContentType())) {
					errorMessage.add("Upload Original File" + " " + fil.getOriginalFilename());
				}
				
				FileEntity obj = new FileEntity();
				obj.setFileName(fil.getOriginalFilename());
//              obj.setDisplayName(UUID.randomUUID() + "." + FilenameUtils.getExtension(fil.getOriginalFilename()));
				obj.setPath(uploadDir);
				obj.setName(objects.getName());
				fil.transferTo(new File(uploadDir + obj.getFileName()));
				obj.setLink(uploadDir + obj.getFileName());
				fileRepository.save(obj);				
				listFile.add(obj);
				savedFile.setResult(listFile);
			} catch (HandlingException e) {
				savedFile.setException(e.getErrorMessage());
				System.out.println(savedFile.getException());
			}
		}
		if (errorMessage.size() > 0) {
			throw new HandlingException(errorMessage);
		}
		return savedFile;
	}

	@Override
	public List<FileEntity> select(String name) {
		List<FileEntity> obj = fileRepository.select(name);
		List<FileEntity> saved = new ArrayList<FileEntity>();
		for (FileEntity obj1 : obj) {
			HttpHeaders headers = new HttpHeaders();
			headers.add("Content-Disposition", "attachment; filename=" + obj1.getFileName());
//			obj1.setHttpHeaders(headers);
			saved.add(obj1);
		}
		return saved;
	}

}
