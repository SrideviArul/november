package com.file.demo.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import com.file.demo.dto.FileDto;
import com.file.demo.entity.FileEntity;
import com.file.demo.exception.CustomError;
import com.file.demo.exception.CustomException;
import com.file.demo.exception.FileHandlingController;
import com.file.demo.service.FileService;

@RestController
@RequestMapping("api/file")
public class FileController  extends FileHandlingController  {

	@Autowired
	public FileService fileServices;

	@RequestMapping(value = "/create", method = RequestMethod.POST)
	@ResponseStatus(code = HttpStatus.OK)
	public FileDto create(@ModelAttribute FileEntity objects, @RequestParam List<MultipartFile> file)
			throws IOException {
		return fileServices.create(objects, file);
	}

	@RequestMapping(value = "/{name}", method = RequestMethod.GET)
	@ResponseStatus(code = HttpStatus.OK)
	public List<FileEntity> select(@PathVariable String name) {
		return fileServices.select(name);
	}
	
//	@RequestMapping(value = "getname", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_UTF8_VALUE })
//	@ResponseStatus(HttpStatus.OK)public Boolean getError() {
//		return addErrorMessage.size() > 0 ? true : false;
//	}
	
	@ResponseBody
	public String getName() throws CustomException {
		CustomError error = new CustomError();
		error.addErrorMessage("name is null");
		error.addErrorMessage("Email is null");
		if (error.getError()) {
//			throw new CustomException(error);
		}
		return "name";
	}
}
