package com.file.demo.service;

import java.io.IOException;
import java.util.List;
import org.springframework.web.multipart.MultipartFile;

import com.file.demo.dto.FileDto;
import com.file.demo.entity.FileEntity;

public interface FileService {

	FileDto create(FileEntity objects , List<MultipartFile> values) throws IOException;
	
	List<FileEntity> select(String name);

//	List<File> select();
//
//	FileEntity update(int id, File values);
//
//	void delete(int id);
}
