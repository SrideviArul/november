package com.file.demo.exception;

import java.io.IOException;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class FileHandlingController {

	@ExceptionHandler(HandlingException.class)
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	public List<String> handlingException(HandlingException error) {
		return error.getErrorMessage();
	}

	@ExceptionHandler(IOException.class)
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	public String ioException(IOException error) {
		return error.getMessage();
	}
	
	@ExceptionHandler
	@ResponseBody
	public CustomError handleException(CustomException ex) {
		
		return ex.getError();
	}
	
}
