package com.file.demo.exception;

public class CustomException extends Exception {
	
	public CustomException() {
		super();
	}
	
	private CustomError error;
	
	private Integer errorCode;
	
	public CustomException(Integer errorCode, CustomError error) {
		this.error = error;
		this.errorCode =errorCode;
	}

	public CustomError getError() {
		return error;
	}

	public void setError(CustomError error) {
		this.error = error;
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(Integer errorCode) {
		this.errorCode = errorCode;
	}
	
	
}
