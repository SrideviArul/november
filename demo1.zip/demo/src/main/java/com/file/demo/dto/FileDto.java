package com.file.demo.dto;

import java.util.List;

import com.file.demo.entity.FileEntity;

public class FileDto {

	private List<FileEntity> result;

	private List<String> Exception;

	public List<FileEntity> getResult() {
		return result;
	}

	public void setResult(List<FileEntity> result) {
		this.result = result;
	}

	public List<String> getException() {
		return Exception;
	}

	public void setException(List<String> exception) {
		Exception = exception;
	}


	
}
