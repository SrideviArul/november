package com.file.demo.exception;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class CustomError {

	public List<String> addErrorMessage = new ArrayList<String>();
	
	public Map<String, String> fieldError = new HashMap<String, String>();
	
	public List<String> getAddErrorMessage() {
		return addErrorMessage;
	}

	public void setAddErrorMessage(List<String> addErrorMessage) {
		this.addErrorMessage = addErrorMessage;
	}
	
	public void addErrorMessage(String errorMessage) {
		addErrorMessage.add(errorMessage);
	}
	
	public Map<String, String> getFieldError() {
		return fieldError;
	}

	public void setFieldError(Map<String, String> fieldError) {
		this.fieldError = fieldError;
	}
	
	public void setFieldError(String key, String message) {
		fieldError.put(key, message);
	}

	@JsonIgnore
	public Boolean getError() {
		return addErrorMessage.size() > 0 ? true : false || !fieldError.isEmpty() ? true : false;
	}
	
}
