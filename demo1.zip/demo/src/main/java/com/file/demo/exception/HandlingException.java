package com.file.demo.exception;

import java.util.List;

public class HandlingException extends RuntimeException {
    
	private List<String> errorMessage;
	
	public HandlingException(List<String> message) {
		super();
		this.errorMessage = message;
	}
	
	public List<String> getErrorMessage(){
		return errorMessage;
	}
//	public HandlingException(String message) {
//		super(message);
//		
//	}
//	
}
