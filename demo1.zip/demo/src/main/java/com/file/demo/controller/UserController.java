package com.file.demo.controller;

import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.file.demo.exception.CustomError;
import com.file.demo.exception.CustomException;
import com.file.demo.exception.FileHandlingController;

@RestController
@RequestMapping("/api/user")
public class UserController {
	
	@RequestMapping(value = "register", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public String registerNewUser() throws CustomException {
		CustomError error = new CustomError();
		error.setFieldError("name", "Already exist");
		error.setFieldError("email", "Already exist");
		if (error.getError()) {
			throw new CustomException(500, error);
		}
		return "name";
	}
}
