package com.task.libo.serviceinterface;

import java.util.*;

import com.task.libo.InsufficientException.MedicineInsufficientException;
import com.task.libo.entity.Customer;

public interface CustomerInterface {

    Customer save(Customer customer);

    Customer read(Integer id);

    void delete(Integer id) throws MedicineInsufficientException;

    Customer update(Integer id, Customer customer);

    List<Customer> getAllCustomers();
    
    List<Object> getAllCustomer();

   

   

    

    
    

}
