package com.task.libo.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.task.libo.InsufficientException.ExceptionHandling;
import com.task.libo.InsufficientException.MedicineInsufficientException;
import com.task.libo.entity.Customer;
import com.task.libo.serviceinterface.CustomerInterface;


@Controller
@RequestMapping("/api/customer/")
public class CustomerController extends ExceptionHandling {
    
    @Autowired
    CustomerInterface customerInterface;
    
    /**
     * Create the customer details.
     * 
     * @param customer details
     * @return the customer details.
     */
    @RequestMapping(value="/create",method =RequestMethod.POST )
    @ResponseBody
    public Customer create(@RequestBody Customer customer) {
        return customerInterface.save(customer);
        } 
    
    /**
     * Get the customer details using customer id.
     * 
     * @param customer id
     * @return the customer details.
     */
    @RequestMapping(value="/{id}",method =RequestMethod.GET)
    @ResponseBody
    public Customer read(@PathVariable Integer id) {
        return customerInterface.read(id);
    }
    
    /**
     * Get the customer details.
     * 
     * @return the  list of customer details.
     */
    @RequestMapping(value="/full",method =RequestMethod.GET )    
    @ResponseBody
    public List<Customer> getAllCustomers() {
        return customerInterface.getAllCustomers();
    }
    
    /**
     * Get the medicine details.
     * 
     * @return the  list of medicine details.
     */
    @RequestMapping(value="/customer",method =RequestMethod.GET)
    public String showCustomer(Model model) {
        List<Object> customer =customerInterface.getAllCustomer(); 
        model.addAttribute("listCustomerDetails",customer);
        return "CustomerList";
    }
    /**
     * 
     * @param update the customer details
     * @param id customer id
     * @return the customer details.
     */
    @RequestMapping(value = "/{id}", method = RequestMethod.PUT)
    @ResponseBody
    public Customer update(@RequestBody Customer customer,@PathVariable Integer  id) {
        return customerInterface.update(id,customer);
    }
    
    /**
     * Delete the customer details.
     * 
     * @param id customer id
     * @throws MedicineInsufficientException 
     */
    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
    public  void delete( @PathVariable Integer  id) throws MedicineInsufficientException  {
        customerInterface.delete(id);   
    }

}
