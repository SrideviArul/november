package com.task.libo.InsufficientException;

public class MedicineInsufficientException extends Exception {

    
    private String errorMsg;

    public MedicineInsufficientException(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    /**
     * @return the errorMsg
     */
    public String getErrorMsg() {
        return errorMsg;
    }

    /**
     * @param errorMsg the errorMsg to set
     */
    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

}
