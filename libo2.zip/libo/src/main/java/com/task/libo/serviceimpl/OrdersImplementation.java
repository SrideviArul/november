package com.task.libo.serviceimpl;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.task.libo.InsufficientException.MedicineInsufficientException;
import com.task.libo.entity.Medicine;
import com.task.libo.entity.OrderDetails;
import com.task.libo.entity.Orders;
import com.task.libo.entity.OrderDetails;
import com.task.libo.repository.MedicineRepository;
import com.task.libo.repository.OrdersRepository;
import com.task.libo.serviceinterface.MedicineInterface;
import com.task.libo.serviceinterface.OrdersInterface;

@Service
public class OrdersImplementation implements OrdersInterface {

    @Autowired
    MedicineRepository medrepo;
    
    @Autowired
    MedicineInterface medicineInterface; 
    
    @Autowired
    OrdersRepository orderRepo;
    

    @Override
    public void delete(Integer id) {
        orderRepo.deleteById(id);
    }

    @Override
    public List<Orders> getAllOrders() {
        return orderRepo.findAll();
    }

    @Override
    public Orders read(Integer id) {
        return orderRepo.findByEntityId(id);
    }

    @Override
    public Orders save(Orders orders) throws MedicineInsufficientException {
        validateMedicine(orders);
        orders.setOrderDate(LocalDateTime.now());
        orders = orderRepo.save(orders);
        for (OrderDetails products : orders.getListOfMedicine()) {
            Medicine medicine = medicineInterface.read(products.getMedicineId().intValue());
            if (medicine != null) {
                medicine.setQuantity(medicine.getQuantity() - products.getQuantity());
                medicineInterface.save(medicine);
            }
        }
        return orders;
    }
    @Override
    public Orders update(Orders orders, Integer id) {
       Orders ord = orderRepo.findByEntityId(id);
        if (ord != null) {
                   
            ord.setQuantity(orders.getQuantity());
            
            return orderRepo.save(orders);
        }
        return null; 
    }

    @Override
    public List<Object> getAllPurchases() {
        
        return orderRepo.findAllOrdersWithCustomer();
    }

    @Override
    public List<Object> getAllOrder() {       
        return orderRepo.findAllOrder();
    }

    private void validateMedicine(Orders orders) throws MedicineInsufficientException {
        List<OrderDetails> listProducts = orders.getListOfMedicine();
        for (OrderDetails products : listProducts) {
            Medicine medicine = medicineInterface.read(products.getMedicineId().intValue());
            if (medicine != null) {
                if (medicine.getQuantity() != null && medicine.getQuantity() < products.getQuantity()) {
                    throw new MedicineInsufficientException("Medicine quantity is less : " + medicine.getName());
                }
            }
        }
    }

    @Override
    public Orders findId(Integer id) {
        return orderRepo. findId(id);
    }

    @Override
    public List<Object> findMedi() {        
        return orderRepo.findMedi();
    }

 
}
