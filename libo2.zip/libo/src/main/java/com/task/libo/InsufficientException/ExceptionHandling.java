package com.task.libo.InsufficientException;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

public class ExceptionHandling extends RuntimeException {

    @ExceptionHandler
    @ResponseBody
    String handleException(MedicineInsufficientException ex) {
        return ex.getErrorMsg();
    }
}
