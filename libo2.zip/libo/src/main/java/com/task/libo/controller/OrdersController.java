package com.task.libo.controller;
import java.util.List;
import org.springframework.ui.Model;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.task.libo.InsufficientException.ExceptionHandling;
import com.task.libo.InsufficientException.MedicineInsufficientException;
import com.task.libo.entity.Orders;
import com.task.libo.repository.MedicineRepository;
import com.task.libo.serviceinterface.OrdersInterface;


@Controller
@RequestMapping("/api/orders/")
public class OrdersController extends ExceptionHandling{
    
    @Autowired
    OrdersInterface ordersInterface;
    
    @Autowired
    MedicineRepository medrepo;
    
    /**
     * Create the order details entity.
     * 
     * 
     * @return order details
     * @throws Exception 
     */
    @RequestMapping(value="/create",method =RequestMethod.POST )
    @ResponseBody
    public Orders create(@RequestBody Orders orders) throws MedicineInsufficientException {
        return ordersInterface.save(orders);
    }   
    
    /**
     * Get the order details using id.
     * 
     * @param id order id
     * @return order details
     */
    @RequestMapping(value="/read/{id}",method = RequestMethod.GET)
    @ResponseBody
    public Orders findId(@PathVariable Integer id) {
        return ordersInterface.findId(id);
    }
      
    /**
     * Get the order details using id.
     * 
     * @param id order id
     * @return order details
     */
    @RequestMapping(value="/{id}",method = RequestMethod.GET)
    @ResponseBody
    public Orders read(@PathVariable Integer id) {
        return ordersInterface.read(id);
    }
    
    /**
     * 
     * @return list of order details 
     */
    @RequestMapping(value="/full",method = RequestMethod.GET)
    @ResponseBody
    public List<Orders> getAllOrders() {
        return ordersInterface.getAllOrders();
    }
    
    /**
     Get Model for get their functions.
     
     @param model
     @return the customer name and product price
    */

    @RequestMapping( value="/purchasing", method = RequestMethod.GET)
    public String showOrders(Model model) {
        List<Object> purchasing = ordersInterface.getAllOrder(); 
        model.addAttribute("listOrderDetails",purchasing);
        return "OrderList"; 
        }
    
    @RequestMapping( value="/purchase", method = RequestMethod.GET)
    public String showPurchases(Model model) {
      List<Object> purchasing = ordersInterface.getAllPurchases(); 
      model.addAttribute("listPurchaseDetails",purchasing);
      return "PurchaseList"; 
      }
       
    @RequestMapping( value="/medicineid", method = RequestMethod.GET)
    @ResponseBody
    public  List<Object>medicineId(){
        return ordersInterface.findMedi(); 
        }
    /**Get the order id.
     * 
     * @param order
     * @param id
     * @return the order details
     */
    @RequestMapping(value = "/{id}", method = RequestMethod.PUT)
    @ResponseBody
    public Orders update(@RequestBody Orders orders,@PathVariable  Integer id) {
        return ordersInterface.update( orders,id);
    }
    
    /**Get the order id and delete the record from order table.
     * 
     * @param id
     */
    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
    public  void delete( @PathVariable Integer  id) {
        ordersInterface.delete(id);
    }
}
