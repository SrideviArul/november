package com.task.libo.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.task.libo.entity.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Integer> {
    
    @Query(value ="SELECT customer FROM Customer customer WHERE customer.id = :id")
    Customer findByEntityId(@Param("id") Integer id); 
 
    @Query(value="select customer.id,customer.name,customer.no  from Customer customer")
    List<Object> findAllCustomer();

    
}
