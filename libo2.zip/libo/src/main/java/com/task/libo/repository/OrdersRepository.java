package com.task.libo.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.task.libo.entity.Orders;

@Repository
public interface OrdersRepository  extends JpaRepository<Orders, Integer>{

    @Query(value="SELECT orders FROM Orders orders WHERE orders.id = :id ")
    Orders findByEntityId(@Param("id")Integer id);
    
    @Query(value="SELECT orders FROM Orders orders WHERE orders.customerId = :id ")
    Orders findId(@Param("id")Integer id);
    
    @Query( "select  customer.id,customer.name,coalesce(orders.cost,'0') from Customer customer left join Orders orders on customer.id=orders.customerId")
    List<Object> findAllOrdersWithCustomer();
  
    @Query(value="select orders.id,orders.customerId,orders.cost,orders.quantity,orders.orderDate  from Orders orders")
    List<Object> findAllOrder();
    
    //@Query(value="SELECT COUNT(DISTINCT orders.customerId),customer.id,customer.name FROM Orders orders JOIN Orders orders listOfMedicine  ON orders.id = listOfMedicine.ordersId JOIN Product product  ON listOfMedicine.list_of_medicine_id = product.id join  Customer customer  on customer.id=orders.customerId WHERE product.medicineId = 1  group by customer.id")
    @Query(value="select orders.id,orders.customerId,orders.cost,orders.quantity,orders.orderDate  from Orders orders")
    List<Object> findMedi();
    
}
