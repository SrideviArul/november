package com.task.libo.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.task.libo.entity.Customer;
import com.task.libo.entity.Medicine;
import com.task.libo.serviceinterface.MedicineInterface;

@Controller
@RequestMapping("/api/medicine/")
public class MedicineController {

    @Autowired
    MedicineInterface medicineInterface;
    
    /**Create the medicine details. 
     * 
     * @param medicine details
     * @return the medicine details.
     */
    @RequestMapping(value="/create",method =RequestMethod.POST )
    @ResponseBody
    public Medicine create(@RequestBody Medicine medicine) {
        return medicineInterface.save(medicine);
        }    
        
    /**
     * Get the medicine details using customer id.
     * 
     * @param medicine id
     * @return the medicine details.
     */
    @RequestMapping(value="/{id}",method =RequestMethod.GET)
    @ResponseBody
    public Medicine read(@PathVariable Integer id) {
        return medicineInterface.read(id);
    }
    
    /**
     * Get the medicine details.
     * 
     * @return the  list of medicine details.
     */
    @RequestMapping(value="/full",method =RequestMethod.GET)
    @ResponseBody
    public List<Medicine> getAllMedicineDetails() {
        return medicineInterface.getAllMedicine();
    }
    
    /**
     * Get the medicine details.
     * 
     * @return the  list of medicine details.
     */
    @RequestMapping(value="/medicine",method =RequestMethod.GET)
    public String showMedicine(Model model) {
        List<Object> medicine =medicineInterface.getAllMedicines(); 
        model.addAttribute("listMedicineDetails",medicine);
        return "MedicineList";
    }
   
    /**
     * 
     * @param update the medicine details
     * @param id medicine id
     * @return the medicine details.
     */
    @RequestMapping(value = "/{id}", method = RequestMethod.PUT)
    @ResponseBody
    public Medicine update(@RequestBody Medicine medicine,@PathVariable Integer id) {
        return medicineInterface.update(id,medicine);
    }
    
    /**
     * Delete the medicine details.
     * 
     * @param id medicine id
     */
    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
    public  void delete( @PathVariable Integer  id) {
        medicineInterface.delete(id);
        
    }
}
