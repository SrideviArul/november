package com.task.libo.serviceinterface;

import java.util.List;

import com.task.libo.entity.Customer;
import com.task.libo.entity.Medicine;

public interface MedicineInterface {
    
    Medicine save(Medicine medicine);

    Medicine read(Integer id);

    void delete(Integer id);

    Medicine update(Integer id, Medicine medicine);

    List<Medicine> getAllMedicine();

    List<Object> getAllMedicines();

  

    
}
