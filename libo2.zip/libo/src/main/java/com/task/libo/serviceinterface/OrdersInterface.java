package com.task.libo.serviceinterface;

import java.util.List;
import java.util.Optional;

import com.task.libo.InsufficientException.MedicineInsufficientException;
import com.task.libo.entity.Orders;

public interface OrdersInterface {

    Orders update(Orders orders, Integer id); 

    void delete(Integer id);

    List<Orders> getAllOrders();
    
    Orders read(Integer id);

    Orders save(Orders orders)throws MedicineInsufficientException;

    List<Object> getAllPurchases();
    
    List<Object> getAllOrder();

    Orders findId(Integer id);

    List<Object> findMedi();


}
