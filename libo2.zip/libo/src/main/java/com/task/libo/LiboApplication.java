package com.task.libo;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LiboApplication {
    
	public static void main(String[] args) {
		SpringApplication.run(LiboApplication.class, args);
		  
	}
	
}
