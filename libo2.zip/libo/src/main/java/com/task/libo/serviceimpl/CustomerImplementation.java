package com.task.libo.serviceimpl;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import com.task.libo.InsufficientException.MedicineInsufficientException;
import com.task.libo.entity.Customer;
import com.task.libo.repository.CustomerRepository;
import com.task.libo.serviceinterface.CustomerInterface;


@Service
public class CustomerImplementation implements CustomerInterface {

    @Autowired
    CustomerRepository customerRepo;

    @Override
    public Customer save(Customer customer) {
        
        if (customer.getNo() != null && !isValidPhone(customer.getNo())) {
            throw new IllegalArgumentException("invalid phone number");
        }
        customer.setCreatedBy(LocalDateTime.now());
        customer.setStatus(true);
        return customerRepo.save(customer);
    }

    @Override
    public Customer read(Integer id) {

        return customerRepo.findByEntityId(id);
    }

    @Override
    public Customer update(@PathVariable Integer id, Customer customer) {
        Customer cus = customerRepo.findByEntityId(id);
        if (cus != null) {
            cus.setName(customer.getName());
            return customerRepo.save(cus);
        }
        return null;
    }

    @Override
    public void delete(Integer id) throws MedicineInsufficientException {
        Customer cust = customerRepo.findByEntityId(id);
        if (cust.getStatus()) {
            cust.setStatus(false);
            customerRepo.save(cust);
        } else {
            throw new MedicineInsufficientException(id + "invalid request");
        }
    }

    @Override
    public List<Customer> getAllCustomers() { 
        return customerRepo.findAll();
    }

    private boolean isValidPhone(String no) {
        String regex = "\\d{10}";
        return no.matches(regex);
    }

    @Override
    public List<Object> getAllCustomer() {
        return customerRepo.findAllCustomer();
    }
}
