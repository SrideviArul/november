package com.json.placeholder.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.json.placeholder.entity.JsonEntity;
import com.json.placeholder.repository.ServiceRepository;

@Service
public class ServiceImple implements ServiceInterface {

	@Autowired
	ServiceRepository serviceRepo;

	@Override
	public JsonEntity create(JsonEntity json) {
		String url = "https://jsonplaceholder.typicode.com/posts/22";
		RestTemplate resttemplate = new RestTemplate();
		ResponseEntity<JsonEntity> responseEntity = resttemplate.getForEntity(url, JsonEntity.class);
		JsonEntity a = responseEntity.getBody();		
		json.setTitle(a.getTitle());
		json.setUserId(a.getUserId());
		json.setBody(a.getBody());
		return serviceRepo.save(json);
	}

	@Override
	public JsonEntity read(Long id) {
	    String url = "https://jsonplaceholder.typicode.com/posts/{id}";
	    RestTemplate restTemplate = new RestTemplate();
	    // Make a GET request to retrieve a specific post
	    ResponseEntity<JsonEntity> responseEntity = restTemplate.getForEntity(url, JsonEntity.class, id);
	    // Check if the response was successful (HTTP status 2xx)
	    if (responseEntity.getStatusCode().is2xxSuccessful()) {
	        return responseEntity.getBody();
	    } else {
	        // Handle unsuccessful response (e.g., log error, throw exception, etc.)
	        throw new RuntimeException("Failed to retrieve post. HTTP status: " + responseEntity.getStatusCodeValue());
	    }
	}

	@Override
	public JsonEntity update(Long id,JsonEntity json) {
		  String url = "https://jsonplaceholder.typicode.com/posts/{id}";
		    RestTemplate restTemplate = new RestTemplate();

		    // Make a GET request to retrieve a specific post
		    ResponseEntity<JsonEntity> responseEntity = restTemplate.getForEntity(url, JsonEntity.class, id);
		    JsonEntity sample  = responseEntity.getBody();
		    if(responseEntity != null) {		    	
		    	sample.setTitle(json.getTitle());		    	
		    }
		return sample;
	}

	@Override
	public JsonEntity delete(Long id) {
		String url = "https://jsonplaceholder.typicode.com/posts/{id}";
	    RestTemplate restTemplate = new RestTemplate();

	    // Make a GET request to retrieve a specific post
	    ResponseEntity<JsonEntity> responseEntity = restTemplate.getForEntity(url, JsonEntity.class, id);
	    JsonEntity sample  = responseEntity.getBody();
	    if(responseEntity != null) {	
		restTemplate.delete(url,id);
		System.out.println("ok");
	}
		return null;

}
}
