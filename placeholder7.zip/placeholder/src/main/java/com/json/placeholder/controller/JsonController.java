package com.json.placeholder.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.json.placeholder.entity.JsonEntity;
import com.json.placeholder.service.ServiceInterface;

@Controller
public class JsonController {
	
	@Autowired
	ServiceInterface serviceInterface;
	
	@RequestMapping(value="/create",method = RequestMethod.POST)
	public JsonEntity create(@RequestBody JsonEntity json) {	
		return serviceInterface.create(json);
	}
	

	@RequestMapping(value="/read/{id}",method = RequestMethod.GET)
	@ResponseBody
	public  JsonEntity create(@PathVariable Long id) {	
		return serviceInterface.read(id);
	}
	
	@RequestMapping(value="/update/{id}",method = RequestMethod.PUT)
	public  JsonEntity update(@PathVariable Long id,@RequestBody JsonEntity json) {	
		return serviceInterface.update(id,json);
	}
	
	@RequestMapping(value="/delete/{id}",method = RequestMethod.DELETE)
	public  JsonEntity delete(@PathVariable Long id) {	
		return serviceInterface.delete(id);
	}
	@RequestMapping(value="/login",method = RequestMethod.GET)
	public  String  create() {	
		return "index.jsp";
	}
	
}
