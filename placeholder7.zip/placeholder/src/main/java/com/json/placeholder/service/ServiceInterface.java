package com.json.placeholder.service;

import com.json.placeholder.entity.JsonEntity;

public interface ServiceInterface {
    JsonEntity create(JsonEntity json);

	JsonEntity read(Long id);

	JsonEntity update(Long id, JsonEntity json);

	JsonEntity delete(Long id);
}
