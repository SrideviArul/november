package com.json.placeholder.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.json.placeholder.entity.JsonEntity;
@Repository
public interface ServiceRepository extends JpaRepository<JsonEntity, Long>{

}
