package com.json.placeholder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlaceholderApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlaceholderApplication.class, args);
	}

}
