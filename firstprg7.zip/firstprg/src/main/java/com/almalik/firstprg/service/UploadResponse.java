package com.almalik.firstprg.service;

import java.util.List;

import com.almalik.firstprg.entity.FileEntity;

public class UploadResponse {

	 private List<FileEntity> successFiles;
	 
	 private List<FileEntity> errorFiles;
	 
	 private List<String> errorMsg;
	 

	public List<String> getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(List<String> errorMsg) {
		this.errorMsg = errorMsg;
	}
	public List<FileEntity> getSuccessFiles() {
		return successFiles;
	}
	public void setSuccessFiles(List<FileEntity> successFiles) {
		this.successFiles = successFiles;
	}
	public List<FileEntity> getErrorFiles() {
		return errorFiles;
	}
	public void setErrorFiles(List<FileEntity> errorFiles) {
		this.errorFiles = errorFiles;
	}
	
}
