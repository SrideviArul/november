package com.almalik.firstprg.service;
import java.util.List;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import com.almalik.firstprg.entity.FileEntity;

public interface ServiceInterface {
	
	ResponseEntity<Resource> download(String fileName) throws Throwable; 
	
	UploadResponse upladFile(FileEntity fe) throws Throwable;
	
	List<Object> read(String email) throws Throwable;

}
