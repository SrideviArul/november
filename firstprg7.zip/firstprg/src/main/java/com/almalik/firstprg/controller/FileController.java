package com.almalik.firstprg.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import com.almalik.firstprg.entity.FileEntity;
import com.almalik.firstprg.exception.FileException;
import com.almalik.firstprg.service.ServiceInterface;
import com.almalik.firstprg.service.UploadResponse;

@Controller
@RequestMapping("api/file")
public class FileController extends FileException {

	@Autowired
	private ServiceInterface serviceInterface;
	
	@Value("${spring.file.upload-dir}")
	private String uploadDir;

	@RequestMapping(value = "/upload", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public String showUploadForm() {
		return "file";
	}

	@RequestMapping(value = "/download/{fileName}", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Resource> download(@PathVariable String fileName) throws Throwable {
		return serviceInterface.download(fileName);
	}

	@RequestMapping(value = "/create", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.CREATED)
	@ResponseBody
	public UploadResponse create(@ModelAttribute FileEntity fe) throws Throwable {
		return serviceInterface.upladFile(fe);
	}
	
	@RequestMapping(value = "/read/{email}", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public List<Object> read(@PathVariable String  email) throws Throwable {
	return serviceInterface.read(email);	
	}

}
