package com.almalik.firstprg.service;

import com.almalik.firstprg.entity.User;

public interface UserServiceInterface {
	
	User create(User user) throws Throwable;

	Boolean login(User user)throws Throwable;
	
}
