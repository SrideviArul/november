package com.almalik.firstprg.service;
import java.io.File;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.apache.tika.Tika;
import org.apache.tika.config.TikaConfig;
import org.apache.tika.mime.MediaType;
import org.apache.tika.mime.MimeType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import com.almalik.firstprg.Repository.ServiceRepo;
import com.almalik.firstprg.entity.FileEntity;
import com.almalik.firstprg.exception.CustomException;

@Service
public class ServiceImp implements ServiceInterface {

	@Value("${spring.file.upload-dir}")
	private String uploadDir;
    
	
	@Autowired
	ServiceRepo serviceRepo;

	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceImp.class);
	
	@Override
	public UploadResponse upladFile(FileEntity fe) throws Throwable {
		List<FileEntity> fileReturn = new ArrayList<>();
		List<FileEntity> fileError = new ArrayList<>();
		List<String> errorr = new ArrayList<>();
		UploadResponse uploadResponse = new UploadResponse();
		MultipartFile[] fileList = fe.getFile();
		for (MultipartFile fileObj : fileList) {
			try {
				FileEntity obj = new FileEntity();
				if (fe == null) {
					errorr.add("it is empty" + " " + fileObj.getOriginalFilename());
					throw new CustomException(errorr);
				}
				List<String> extension = Arrays.asList("jpeg", "jpg", "png", "avif");
				String originalFilename = fileObj.getOriginalFilename();
				String fileExtension = originalFilename.substring(originalFilename.lastIndexOf(".") + 1).toLowerCase();
				if (!extension.contains(fileExtension)) {
					errorr.add("Invalid file type. Allowed types: jpg, jpeg, png, avif" + " "
							+ fileObj.getOriginalFilename());
					throw new CustomException(errorr);
				}
				LOGGER.error("File upload started : " + fileObj.getName());
				Tika tikaObj = new Tika();
				String finder = tikaObj.detect(fileObj.getInputStream());
				MimeType mime = TikaConfig.getDefaultConfig().getMimeRepository().forName(fileObj.getContentType());
				String extentionType = mime.getExtension();
				if (MediaType.EMPTY == null) {
					errorr.add("its empty" + " " + fileObj.getOriginalFilename());
					throw new CustomException(errorr);
				}
				if (!(finder.equals(fileObj.getContentType()))) {
					errorr.add(fileObj.getOriginalFilename() + " " + "please upload correct file");
					throw new CustomException(errorr);
				}
				String uidExtention = obj.getRandomUUID() + extentionType;
				String fileName = obj.setFileName(uidExtention);
				obj.setEmail(fe.getEmail());
				obj.setLink(uploadDir + fileName);
				fileObj.transferTo(new File(uploadDir + obj.getFileName()));
				serviceRepo.save(obj);
				fileReturn.add(obj);
			} catch (CustomException e) {
				FileEntity errorFile = new FileEntity();
				errorFile.setFileName(fileObj.getOriginalFilename());
				fileError.add(errorFile);
			}
		}
		uploadResponse.setErrorFiles(fileError);
		uploadResponse.setErrorMsg(errorr);
		uploadResponse.setSuccessFiles(fileReturn);
		return uploadResponse;
	}

	private boolean isValidEmail(String email) {
		String regex = "^[a-z0-9]{5,15}+@[a-z]{2,5}+.[a-z]{2,3}$";
		return email.matches(regex);
	}

	@Override
	public ResponseEntity<Resource> download(String fileName) throws Throwable {
		Path filePath = Paths.get(uploadDir + fileName);
		Resource resource = new UrlResource(filePath.toUri());
		if (resource.exists()) {
			HttpHeaders headers = new HttpHeaders();
			headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + fileName);
			return ResponseEntity.ok().headers(headers).body(resource);
		} else {
			List<String> errorr = new ArrayList<>();
			errorr.add("File not found: " + fileName);
			throw new CustomException(errorr);
		}
	}

	@Override
	public List<Object> read(String email) {
		return serviceRepo.list(email);
	}
}
