package com.almalik.firstprg;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

public class SessionManager {
	 public static void createSession(HttpServletRequest request, String attributeName, String attributeValue) {
	        HttpSession session = request.getSession(true);
	        session.setAttribute(attributeName, attributeValue);
	    }

	    public static String getSessionAttribute(HttpServletRequest request, String attributeName) {
	        HttpSession session = request.getSession(false);
	        if (session != null) {
	            return (String) session.getAttribute(attributeName);
	        }
	        return null;
	    }

	    public static void invalidateSession(HttpServletRequest request) {
	        HttpSession session = request.getSession(false);
	        if (session != null) {
	            session.invalidate();
	        }
	    }
	}
