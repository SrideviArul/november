package com.almalik.firstprg;
import java.security.SecureRandom;
import java.util.Base64;

public class SessionTokenGenerator {
	   public static String generateSessionToken() {
	        SecureRandom random = new SecureRandom();
	        byte[] tokenBytes = new byte[32]; // You can adjust the length as needed
	        random.nextBytes(tokenBytes);
	        return Base64.getEncoder().encodeToString(tokenBytes);
	    }
}
