package com.almalik.firstprg.Repository;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.almalik.firstprg.entity.FileEntity;

@Repository
public interface ServiceRepo extends JpaRepository<FileEntity, Long>{
	
	@Query("SELECT fileEntity.fileName,fileEntity.link FROM FileEntity fileEntity INNER JOIN User user ON fileEntity.email = user.email")
	List<Object> list(@Param("email") String email);

  
}
