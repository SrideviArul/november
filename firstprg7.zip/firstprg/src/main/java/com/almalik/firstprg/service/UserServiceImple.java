package com.almalik.firstprg.service;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.almalik.firstprg.SessionManager;
import com.almalik.firstprg.SessionTokenGenerator;
import com.almalik.firstprg.Repository.UserRepo;
import com.almalik.firstprg.entity.User;
import com.almalik.firstprg.exception.CustomException;
import org.slf4j.Logger;
import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.LoggerFactory;
@Service
public class UserServiceImple  implements UserServiceInterface{


	private static final Logger LOGGER = LoggerFactory.getLogger(UserServiceImple.class);
	@Autowired
	private UserRepo userRepo;
	
	@Override
	public User create(User user) throws Throwable {
		List<String> errorr = new ArrayList<>();
		if(user.getPassword()==null) {
			errorr.add( "please upload correct file");
			throw new CustomException(errorr);
		}
		if(!validPassword(user.getPassword())) {
			errorr.add("give valid password");
			throw new CustomException(errorr);
		}
		LOGGER.error("File upload started : " +user.getEmail());
		System.out.println("byugbhu");
		user.setStatus(true);
		user.setCreatedBy(LocalDateTime.now());
		return userRepo.save(user);
	}
	private boolean validPassword(String pass) {	
	    String regex = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).{8,}$";
	    return pass.matches(regex);
	}
	
	@Override
	public Boolean login(User user) throws Throwable {
		List<String> errorr = new ArrayList<>();
		String email = user.getEmail();
		String password = user.getPassword();
       if(userRepo.existsByPassword(password) && userRepo.existsByEmail(email)) {
    	   String sessionToken = SessionTokenGenerator.generateSessionToken();
    	   HttpServletRequest request = null;
           SessionManager.createSession(request, "sessionToken", sessionToken);
		return true;
	}
       errorr.add("incorrect password and name");
	throw new  CustomException(errorr);
}
}
