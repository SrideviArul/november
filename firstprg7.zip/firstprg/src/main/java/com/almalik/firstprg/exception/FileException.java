package com.almalik.firstprg.exception;

import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

import org.springframework.web.bind.annotation.ExceptionHandler;

public class FileException {
                                                                 
	
	 @ExceptionHandler
	 @ResponseBody public List<String> HandlerException(CustomException ex) {
	  return ex.getErrorMsg();
   	}
    
	}
	
	

