package com.almalik.firstprg.exception;

import java.util.ArrayList;
import java.util.List;

public class CustomException extends RuntimeException{
	
	private List<String> errorMsg;

	public List<String> getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(List<String> errorMsg) {
		this.errorMsg = errorMsg;
	}

	public CustomException(List<String> errorMsg) {
		this.errorMsg = errorMsg;
	}
   
}