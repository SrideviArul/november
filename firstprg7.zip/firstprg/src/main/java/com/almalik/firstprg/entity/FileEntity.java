package com.almalik.firstprg.entity;

import java.io.File;
import java.util.List;
import java.util.UUID;

import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Transient;

/**
 * File details in customer entity
 */
@Entity
@JsonIgnoreProperties({ "id","email","link","userId","user","file","randomUUID"}) 
public class FileEntity {

	/** Customer **/
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	

	@Transient
	private UUID randomUUID = UUID.randomUUID();

	public UUID getRandomUUID() {
		return randomUUID;
	}

	public void setRandomUUID(UUID randomUUID) {
		this.randomUUID = randomUUID;
	}

	@Column(name = "email", columnDefinition = "varchar(30)")
	private String email;

	private String fileName;

	@Transient
	private MultipartFile[] file;

	private String link;
	
	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	public MultipartFile[] getFile() {
		return file;
	}

	public void setFile(MultipartFile[] file) {
		this.file = file;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the randomUUID
	 */

	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * @param fileName the fileName to set
	 * @return
	 */
	public String setFileName(String fileName) {
		return this.fileName = fileName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
}
